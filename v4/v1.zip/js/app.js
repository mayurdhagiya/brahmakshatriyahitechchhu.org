// Responsive Menu Toggle
document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.getElementById('menu-toggle');
    const navigation = document.getElementById('navigation');

    menuToggle.addEventListener('click', () => {
        navigation.classList.toggle('active'); // Toggle 'active' class for menu
    });
});

/**
 * Load editions from data.js and display on the home page.
 */
function loadEditions() {
    // Use editionsData from data.js
    const currentEdition = editionsData[0]; // Latest edition
    const currentContainer = document.querySelector(".edition");

    // Current Edition
    currentContainer.innerHTML = `
        <div class="card">
            <img src="${currentEdition.cover}" alt="Cover ${currentEdition.year}">
            <h3>${currentEdition.edition}</h3>
            <p>Publication Date: ${currentEdition.date}</p>
            <button onclick="window.open('${currentEdition.link}', '_blank')">Read Now</button>
        </div>
    `;

    // Group previous editions by year
    const previousEditions = editionsData.slice(1); // Skip the first row (current edition)
    const groupedEditions = previousEditions.reduce((acc, edition) => {
        acc[edition.year] = acc[edition.year] || [];
        acc[edition.year].push(edition);
        return acc;
    }, {});

    // Display previous editions
    const previousContainer = document.getElementById("previous-editions");
    Object.keys(groupedEditions)
        .sort((a, b) => b - a) // Sort by year descending
        .forEach(year => {
            const yearGroup = document.createElement("div");
            yearGroup.classList.add("year-group");
            yearGroup.innerHTML = `<h3>${year}</h3><div class="year-scroll"></div>`;

            const scrollContainer = yearGroup.querySelector(".year-scroll");
            groupedEditions[year].forEach(edition => {
                const card = document.createElement("div");
                card.classList.add("card");
                card.innerHTML = `
                    <img src="${edition.cover}" alt="Cover ${edition.year}">
                    <h3>${edition.edition}</h3>
                    <p>${edition.date}</p>
                    <button onclick="window.open('${edition.link}', '_blank')">Read Now</button>
                `;
                scrollContainer.appendChild(card);
            });

            previousContainer.appendChild(yearGroup);
        });
}

/**
 * Load trustees from data.js and display on the trustee page.
 */
function loadTrustees() {
    const groupedTrustees = trusteesData.reduce((acc, trustee) => {
        if (!acc[trustee.designation]) {
            acc[trustee.designation] = [];
        }
        acc[trustee.designation].push(trustee);
        return acc;
    }, {});

    const container = document.getElementById("trustee-container");

    Object.keys(groupedTrustees).forEach(designation => {
        const section = document.createElement("div");
        section.classList.add("trustee-group");
        section.innerHTML = `<h3 class="designation-title">${designation}</h3>`;

        groupedTrustees[designation].forEach(trustee => {
            const card = document.createElement("div");
            card.classList.add("trustee-card");
            card.innerHTML = `
                <img src="${trustee.image}" alt="${trustee.name}" class="trustee-image">
                <h4>${trustee.name}</h4>
                <div class="trustee-actions">
                    <a href="${trustee.phone}" title="Call"><i class="fas fa-phone"></i></a>
                    <a href="${trustee.whatsapp}" title="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                    <a href="${trustee.email}" title="Email"><i class="fas fa-envelope"></i></a>
                </div>
                <div class="trustee-social">
                    <a href="${trustee.social.facebook}" target="_blank" title="Facebook"><i class="fab fa-facebook"></i></a>
                    <a href="${trustee.social.twitter}" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="${trustee.social.instagram}" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="${trustee.social.linkedin}" target="_blank" title="LinkedIn"><i class="fab fa-linkedin"></i></a>
                </div>
            `;
            section.appendChild(card);
        });

        container.appendChild(section);
    });
}
